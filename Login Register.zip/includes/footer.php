			<div class="footer">
               @copy All rights reserved to Md. jubaer hossain
           </div>
        </div>
    </body>

    <script src="js/app.js"></script>
</html>

<style type="text/css">
	.footer{
		display: block;
		margin-bottom: 0;
		padding: 1rem 0;
		text-align: center;
		background-color: #f2f6fc;
		bottom: 0px;
		width: 1140px;
		color: #575757;
		border: 1px solid lightgray;
	}
</style>